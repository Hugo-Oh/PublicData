#!/usr/bin/env python
# coding: utf-8

def print3(st):
    print('*' * 50)
    print(st)
    print('-' * 50)

def print4(st):
    print('-' * 50)
    print(st)
    print('*' * 50)



