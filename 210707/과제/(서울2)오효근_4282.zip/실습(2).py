#!/usr/bin/env python
# coding: utf-8

# In[2]:


x, y = 10, 5 #tuple


# In[3]:


x == y
(x ==y) 


# In[8]:


x != y


# In[9]:


x > y


# In[10]:


x < y


# In[11]:


x >= y


# In[12]:


x <= y


# In[ ]:





# In[5]:


x = True; y = False


# In[8]:


x and y and not x


# In[15]:


x or y


# In[16]:


not x


# In[19]:


x, y = 10, 5


# In[22]:


if x > y:
    print('x가 y보다 큽니다.')


# In[24]:


x, y = 5, 10


# In[10]:


if x > y:
    print('x가 y보다 큽니다.')
else:
    print('x가 y보다 작습니다.')


# In[11]:


x, y = 10, 10


# In[12]:


if x > y:
    print('x가 y보다 큽니다.')
elif x == y:
    print('x와 y가 같습니다.')
elif x < y:
    print('x가 y보다 작습니다.')


# In[13]:


score = 90


# In[14]:


if score >= 90:
    print('A학점입니다.')
elif score >= 80:
    print('B학점입니다.')
elif score >= 70:
    print('C학점입니다.')
elif score >= 60:
    print('D학점입니다.')
else:
    print('F학점입니다.')    


# In[15]:


a = True
if a:
    print("a는 True입니다.")
    print("True End...")
    
else:
    print("a는 False입니다.")
print('False End...')


# In[16]:


x, y = 10, 5


# In[17]:


if x > y:
    print('x가 y보다 큽니다.')


# In[18]:


x, y = 5, 10


# In[19]:


if x > y:
    print('x가 y보다 큽니다.')
else:
    print('x가 y보다 작습니다.')


# In[20]:


x, y = 10, 10


# In[21]:


if x > y:
    print('x가 y보다 큽니다.')
elif x == y:
    print('x와 y가 같습니다.')
elif x < y:
    print('x가 y보다 작습니다.')


# In[22]:


score = 90


# In[23]:


if score >= 90:
    print('A학점입니다.')
elif score >= 80:
    print('B학점입니다.')
elif score >= 70:
    print('C학점입니다.')
elif score >= 60:
    print('D학점입니다.')
else:
    print('F학점입니다.')    


# In[24]:


a = True
if a:
    print("a는 True입니다.")
    print("True End...")
    
else:
    print("a는 False입니다.")
print('False End...')


# In[26]:


x, y = 10, 5

if x > y:
    print('x가 y보다 큽니다.')

x, y = 5, 10

if x > y:
    print('x가 y보다 큽니다.')
else:
    print('x가 y보다 작습니다.')

x, y = 10, 10

if x > y:
    print('x가 y보다 큽니다.')
elif x == y:
    print('x와 y가 같습니다.')
elif x < y:
    print('x가 y보다 작습니다.')
score = 80

if score >= 90:
    print('A학점입니다.')
elif score >= 80:
    print('B학점입니다.')
elif score >= 70:
    print('C학점입니다.')
elif score >= 60:
    print('D학점입니다.')
else:
    print('F학점입니다.')    
a = True
if a:
    print("a는 True입니다.")
    print("True End...")
else:
    print("a는 False입니다.")
print('False End...')


# In[ ]:





# In[ ]:




